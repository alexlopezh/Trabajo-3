<html lang="es">
<head>
<title>Ejercicios en PHP</title>
<meta charset="uft-8"/>
</head>
<body style="background:url('fondo 1.jpg') no-repeat bottom left" width=80% bgcolor="white" border="2">
<h1>EJERCICIOS PHP VARIABLES</h1>
<a href="Ejercicio1.php">Ejercicio 1</a>
<a href="Ejercicio2.php">Ejercicio 2</a>
<a href="Ejercicio3.php">Ejercicio 3</a>
<a href="Ejercicio4.php">Ejercicio 4</a>
<a href="Ejercicio5.php">Ejercicio 5</a>
  <div class="enpi">
<p>UNIVERSIDAD AUTONOMA DE CHIAPAS</p>
	  <img src="img/unach.png" width="150px" height="150px" />
	  <h4>LIC: JEHOVANI ALEXANDER LOPEZ HERNANDEZ</h4>
	  <h4>UNACH LSC 5B A150043</h4>
	  </div>
</body>
</html>